package parcialjunio;

import java.io.Serializable;
import java.util.Random;

/**
 *
 * @author Alumno
 */
public class Vehiculo implements Serializable{

    private double precio;
    private String patente;
    private String marca;
    private String modelo;
    private String color;
    private boolean disponible;
    private int idVehiculo;

    /**
     *
     */
    public Vehiculo() {
    }

    /**
     *
     * @param precio
     * @param patente
     * @param marca
     * @param modelo
     * @param color
     */
    public Vehiculo(double precio, String patente, String marca, String modelo, String color) {
        this.precio = precio;
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.disponible = true;
           Random r = new Random();
        this.idVehiculo = r.nextInt(100) + 1;
        
    }

    /**
     *
     * @return
     */
    public double getPrecio() {
        return precio;
    }

    /**
     *
     * @param precio
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     *
     * @return
     */
    public String getPatente() {
        return patente;
    }

    /**
     *
     * @param patente
     */
    public void setPatente(String patente) {
        this.patente = patente;
    }

    /**
     *
     * @return
     */
    public String getMarca() {
        return marca;
    }

    /**
     *
     * @param marca
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     *
     * @return
     */
    public String getModelo() {
        return modelo;
    }

    /**
     *
     * @param modelo
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     *
     * @return
     */
    public String getColor() {
        return color;
    }

    /**
     *
     * @param color
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     *
     * @return
     */
    public boolean isDisponible() {
        return disponible;
    }

    /**
     *
     * @param disponible
     */
    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    @Override
    public String toString() {
        return "###Vehiculo ####" + "\nprecio= $" + precio + "\npatente= " + patente + "\nmarca= " + marca + "\nmodelo= " + modelo + "\ncolor=" + color + "\ndisponible= " + disponible + "\nidVehiculo= " + idVehiculo ;
    }

    /**
     *
     * @return
     */
    public int getIdVehiculo() {
        return idVehiculo;
    }

    /**
     *
     * @param idVehiculo
     */
    public void setIdVehiculo(int idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

}
