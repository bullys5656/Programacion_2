
package parcialjunio;
import java.io.Serializable;
   import static java.time.temporal.ChronoUnit.DAYS;
import java.time.LocalDate;

/**
 *
 * @author Alumno
 */
public class DetalleReserva implements Serializable{
        private int cantCombus;
        private LocalDate fechaInicio;
        private LocalDate fechaFinal;

    /**
     *
     */
    public DetalleReserva(){
        }

    /**
     *
     * @param cantCombus
     * @param fechaInicio
     * @param fechaFinal
     */
    public DetalleReserva(int cantCombus, LocalDate fechaInicio, LocalDate fechaFinal) {
        this.cantCombus = cantCombus;
        this.fechaInicio = fechaInicio;
        this.fechaFinal = fechaFinal;
    }

    /**
     *
     * @param fechaInicio
     * @param fechaFinal
     */
    public DetalleReserva(LocalDate fechaInicio, LocalDate fechaFinal) {
        this.fechaInicio = fechaInicio;
        this.fechaFinal = fechaFinal;
    }

    /**
     *
     * @return
     */
    public int getCantCombus() {
        return cantCombus;
    }

    /**
     *
     * @param cantCombus
     */
    public void setCantCombus(int cantCombus) {
        this.cantCombus = cantCombus;
    }

    /**
     *
     * @return
     */
    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    /**
     *
     * @param fechaInicio
     */
    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     *
     * @return
     */
    public LocalDate getFechaFinal() {
        return fechaFinal;
    }

    /**
     *
     * @param fechaFinal
     */
    public void setFechaFinal(LocalDate fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    /**
     *
     * @return
     */
    public int calcularDias(){
       //long dias= DAYS.between(fechaHoy, fechaProx); //FechaInicio,FechaFinal. Ha la diferencia entre dos fechas
       int totalDias=(int) DAYS.between(this.fechaInicio,fechaFinal);
       
       return totalDias;} 

    @Override
    public String toString() {
        return "###DetalleReserva###" + "\ncantCombus= " + cantCombus + "\nfechaInicio=" + fechaInicio + "\nfechaFinal= " + fechaFinal + "\nTotalDias= "+calcularDias();
    }

    
        
        
}
