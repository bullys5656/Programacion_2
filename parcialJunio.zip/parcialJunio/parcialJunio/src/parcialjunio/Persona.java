
package parcialjunio;

import java.io.Serializable;

/**
 *
 * @author Alumno
 */
public abstract class Persona implements Serializable {

    private String usuario;
    private String password;

    /**
     *
     * @param usario
     * @param password
     */
    public Persona(String usario ,String password){
        this.usuario= usario;
        this.password=password;
    }
    
    /**
     *
     * @return
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     *
     * @param usuario
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     *
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }
    
    /**
     *
     * @param sistema
     * @return
     */
    public abstract boolean proceder(Sistema sistema);

}
