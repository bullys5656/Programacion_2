package parcialjunio;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Alumno
 */
public class Reserva implements Serializable {

    private DetalleReserva detalleReserva;
    private ArrayList<Vehiculo> vehiculos;
    private Boolean estadoAlquiler;
    private double precioTotal;
    private Cliente cliente;

    /**
     *
     */
    public Reserva() {
        this.vehiculos = new ArrayList<>();
        this.estadoAlquiler = true;
        this.cliente = new Cliente();
        this.detalleReserva = new DetalleReserva();
    }

    /**
     *
     * @param detalleReserva
     * @param vehiculos
     * @param cliente
     */
    public Reserva(DetalleReserva detalleReserva, ArrayList<Vehiculo> vehiculos, Cliente cliente) {
        this.detalleReserva = detalleReserva;
        this.vehiculos = vehiculos;
        this.cliente = cliente;
        calcularPrecio();
        cambiarEstadoV();
    }

    /**
     *
     * @return
     */
    public DetalleReserva getDetalleReserva() {
        return detalleReserva;
    }

    /**
     *
     * @param detalleReserva
     */
    public void setDetalleReserva(DetalleReserva detalleReserva) {
        this.detalleReserva = detalleReserva;
    }

    /**
     *
     * @return
     */
    public ArrayList<Vehiculo> getVehiculos() {
        return vehiculos;
    }

    /**
     *
     * @param vehiculos
     */
    public void setVehiculos(ArrayList<Vehiculo> vehiculos) {
        this.vehiculos = vehiculos;
    }

    /**
     *
     * @return
     */
    public Boolean getEstadoAlquiler() {
        return estadoAlquiler;
    }

    /**
     *
     * @param estadoAlquiler
     */
    public void setEstadoAlquiler(Boolean estadoAlquiler) {
        this.estadoAlquiler = estadoAlquiler;
    }

    /**
     *
     * @return
     */
    public double getPrecioTotal() {
        return precioTotal;
    }

    /**
     *
     * @param precioTotal
     */
    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }

    /**
     *
     * @return
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     *
     * @param cliente
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     *
     */
    public void calcularPrecio(){
   double aux=0;
   int cantVehi=vehiculos.size();
        for (Vehiculo vehiculo : vehiculos) {
            aux=aux+vehiculo.getPrecio();
            
        }
        this.precioTotal=(aux+(cantVehi*detalleReserva.getCantCombus()))*detalleReserva.calcularDias();
    
    }
    
    /**
     *
     */
    public void cambiarEstadoV(){
        for (Vehiculo vehiculo : vehiculos) {
            vehiculo.setDisponible(false);
            
        }
    }

    @Override
    public String toString() {
        return "Reserva{" + "detalleReserva=" + detalleReserva + ", vehiculos=" + vehiculos + ", estadoAlquiler=" + estadoAlquiler + ", precioTotal=" + precioTotal + ", cliente=" + cliente + '}';
    }

   
}
